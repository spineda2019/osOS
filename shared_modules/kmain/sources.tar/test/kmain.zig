//! kmain.zig - The central core of osOS; where the boot routine jumps from setup
//! Copyright (C) 2025 Sebastian Pineda (spineda.wpi.alum@gmail.com)
//!
//! This program is free software: you can redistribute it and/or modify
//! it under the terms of the GNU General Public License as published by
//! the Free Software Foundation, either version 3 of the License, or
//! (at your option) any later version.
//!
//! This program is distributed in the hope that it will be useful,
//! but WITHOUT ANY WARRANTY; without even the implied warranty of
//! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//! GNU General Public License for more details.
//!
//! You should have received a copy of the GNU General Public License
//! along with this program.  If not, see <https://www.gnu.org/licenses/>.

const builtin = @import("builtin");
const process = @import("osprocess");
const osformat = @import("osformat");
const oshal = @import("oshal");
const testoptions = @import("testoptions");

/// Ideally the beginning of true arch agnostic osOS logic, like where the
/// scheduler will start and where pretty much everything that need not know
/// about CPU architecture (mostly) will be initialized.
///
/// Universally common CPU instructions (like jumping to an address, executing
/// and arbitrary illegal instruction for testing, etc) will be provided via
/// functions in `ct_hal`. Might be an escape hatch, but I like the abstraction.
pub fn kmain(rt_hal: oshal.RtHAL, comptime ct_hal: oshal.CtHal) noreturn {
    const Logger = struct {
        serial: osformat.IWriter,
        terminal: osformat.IWriter,

        const Logger = @This();
        fn writef(self: *Logger, comptime format: []const u8, args: anytype) void {
            self.serial.writef(format, args);
            self.terminal.writef(format, args);
        }
        fn flush(self: *Logger) void {
            self.serial.flush();
            self.terminal.flush();
        }
    };
    var logger: Logger = .{
        .serial = rt_hal.serial_io,
        .terminal = rt_hal.terminal,
    };

    logger.writef("********************* kmain *********************\r\n", .{});
    for (0..12) |_| {
        const foo_array: [20][4]u8 = comptime @splat("Foo ".*);
        const foo_str: []const u8 = comptime @ptrCast(&foo_array);
        logger.writef(foo_str, .{});
        const bar_array: [20][4]u8 = comptime @splat("Bar ".*);
        const bar_str: []const u8 = comptime @ptrCast(&bar_array);
        logger.writef(bar_str, .{});
        const baz_array: [20][4]u8 = comptime @splat("Baz ".*);
        const baz_str: []const u8 = comptime @ptrCast(&baz_array);
        logger.writef(baz_str, .{});
    }

    logger.writef("Hey there! We succesfully passed the HAL to kmain\r\n", .{});
    logger.writef("Testing writeLine...\r\n", .{});
    logger.writef("Hi there from a new line!\r\n", .{});
    logger.writef("Hi there from a new line again!\r\n", .{});

    if (testoptions.test_panic) {
        logger.writef("Testing Panic\r\n", .{});
        @panic("Testing Panic");
    }

    if (testoptions.test_ill) {
        logger.writef(
            "Purposefully performing an illegal instruction...\r\n",
            .{},
        );
        ct_hal.assembly_wrappers.illegal_instruction();
    }

    logger.flush();

    const static_process_storage = struct {
        var process_pool: process.ProcessTable(.{
            .max_process_count = 8,
            .context_tools = ct_hal.ctx_tools,
            .stack_size = 1024 * 64,
        }) = undefined;
    };
    static_process_storage.process_pool = .init();

    var module_iterator = rt_hal.boot_module_info.iterator();
    while (module_iterator.next()) |module| {
        logger.writef(
            "Initializing module: '{s}' at addr {*}\r\n",
            .{ module.name, module.physical_address.ptr },
        );
    }
    logger.writef("Beginning to schedule from the process pool\r\n", .{});
    logger.flush();
    // TODO(SEP) somehow call schedule?

    while (true) {
        if (rt_hal.char_buf.vtable.getChar(rt_hal.char_buf.impl)) |scan| {
            logger.writef("Received scan code: {d}\r\n", .{scan});
            logger.flush(); // not needed but good to observe correctness for now
        }
    }
}
