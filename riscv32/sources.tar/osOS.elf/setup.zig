const std = @import("std");
const exception = @import("exception.zig");
const tty = @import("riscv32tty");
const riscv32asm = @import("riscv32asm");
const sbi = @import("sbi/root.zig");
const osformat = @import("osformat");
const oshal = @import("oshal");
const kmain = @import("kmain");
const riscv32hal = @import("hal/hal.zig");
const serial = @import("serial/serial.zig");
const BootInfo = @import("riscv32BootInfo");
const dtb = @import("osdtb");

/// BSS Start
const bss = @extern([*]u8, .{ .name = "__bss" });

/// BSS End
const bss_end = @extern([*]u8, .{ .name = "__bss_end" });

/// Defined externally by the linker script.
pub const free_ram_start: [*]u8 = @extern([*]u8, .{ .name = "__free_ram" });

/// Also defined externally by the linker script.
pub const free_ram_end: [*]u8 = @extern([*]u8, .{ .name = "__free_ram_end" });

pub fn setup(hart_id: u32, dtb_address: [*]const u8) callconv(.c) noreturn {
    const bssSize = @intFromPtr(bss_end) - @intFromPtr(bss);
    @memset(bss[0..bssSize], 0);

    const exception_handler_address = &exception.cpuExceptionHandler;

    asm volatile ("csrw stvec, %[exception_handler]"
        :
        : [exception_handler] "r" (exception_handler_address),
    );

    var terminal = tty.Terminal.init();
    terminal.writeSplashLogo();

    var buffer: [1024]u8 = undefined;
    var terminal_writer: osformat.IWriter = terminal.writer(&buffer);

    terminal_writer.writef("Hello RISC-V32 osOS!\n", .{});
    terminal_writer.writef("Hart ID: {d}\n", .{hart_id});
    terminal_writer.writef("DTB Address: {*}\n", .{dtb_address});

    const fdt: *const dtb.FdtHeader = @ptrCast(@alignCast(dtb_address));
    terminal_writer.writef("FDT Address: {*}\n", .{fdt});
    terminal_writer.writef("FDT info:\n", .{});
    inline for (comptime std.meta.fieldNames(dtb.FdtHeader)) |field_name| {
        const val: dtb.BEU32 = @field(fdt, field_name);
        const little: u32 = val.toNative();
        const format = comptime blk: {
            if (std.mem.eql(u8, field_name, "magic")) {
                break :blk "    ({s}): 0x{x}\n";
            } else {
                break :blk "    ({s}): {d}\n";
            }
        };
        terminal_writer.writef(format, .{ field_name, little });
    }

    const mem_block: []const dtb.MemoryReservationBlock = fdt.getMemEntries();
    terminal_writer.writef("Block start addr: {*}\n", .{mem_block.ptr});
    terminal_writer.writef("Block count: {d}\n", .{mem_block.len});

    terminal_writer.flush();

    var string_block: dtb.StringBlockIterator = fdt.stringBlockIter();
    terminal_writer.writef("String block start addr: {*}\n", .{string_block.begin});
    var string_cnt: usize = 0;
    while (string_block.next()) |block| {
        string_cnt += 1;
        terminal_writer.writef("    String #{d}: {s}\n", .{ string_cnt, block });
    }

    var struct_iter: dtb.StructureBlock.Node.Iterator = fdt.getStructureIter();
    terminal_writer.writef("First Token addr: {*}\n", .{struct_iter.head});
    terminal_writer.writef("First Token val: {d}\n", .{struct_iter.head[0].toNative()});
    terminal_writer.flush();

    // while (struct_iter.next() catch |err| val: {
    // terminal_writer.writef("    struct iter error: {s}\n", .{@errorName(err)});
    // break :val null;
    // }) |node| {
    // terminal_writer.writef("    Unit name: {s}\n", .{node.unit_name});
    // if (node.unit_address) |addr| {
    // terminal_writer.writef("    Unit addr: {s}\n", .{addr});
    // }
    // terminal_writer.writef("    Prop info:\n", .{});
    // }

    const sbi_spec_version = sbi.getSpecVersion();
    terminal_writer.writef(
        "SBI Specification version: {s}.{s}\n",
        .{
            sbi_spec_version.major.getStr(),
            sbi_spec_version.minor.getStr(),
        },
    );
    const sbi_impl: []const u8 = sbi.getImplId();
    terminal_writer.writef("SBI Implementation: {s}\n", .{sbi_impl});

    var serial_stub: serial.SerialPort = .{};
    var serial_buffer: [1024]u8 = undefined;

    kmain.kmain(
        .{
            .terminal = terminal_writer,
            .serial_io = serial_stub.writer(&serial_buffer),
            .boot_module_info = BootInfo.ModuleInfo.moduleProber(),
            .char_buf = .{
                .impl = null,
                .vtable = &.{
                    .getChar = &struct {
                        fn impl(_: ?*anyopaque) ?u8 {
                            return null;
                        }
                    }.impl,
                },
            },
        },
        .{
            .assembly_wrappers = .{
                .jump = riscv32asm.assembly_wrappers.jump,
                .illegal_instruction = riscv32asm.assembly_wrappers.illegal_instruction,
                .wait_for_interrupt = riscv32asm.assembly_wrappers.waitForInterrupt,
            },
            .ctx_tools = .{
                .enableInterrupts = riscv32asm.assembly_wrappers.enableInterrupts,
                .disableInterrupts = riscv32asm.assembly_wrappers.disableInterrupts,
            },
        },
    );
}
